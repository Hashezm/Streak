// document.addEventListener("DOMContentLoaded", function () {
//     const progressElement = document.querySelector(".progress");
//     const madGif = document.querySelector(".gif.mad");
//     const happyGif = document.querySelector(".gif.happy");

//     progressElement.addEventListener("animationiteration", function () {
//         const width = parseFloat(progressElement.style.width);
//         if (width < 50) {
//             madGif.style.display = "block";
//             happyGif.style.display = "none";
//         } else {
//             madGif.style.display = "none";
//             happyGif.style.display = "block";
//         }
//     });
// });
