  // Function to change the width
  function changeWidth() {
    const progressBar = document.getElementById("progress");
    progressBar.style.width = '300px';
    console.log(progressBar.style.width);
  }

 
