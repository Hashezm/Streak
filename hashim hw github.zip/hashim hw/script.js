

chrome.storage.session.get(["key"], (result) => {
    if (result.key) {
        document.getElementById('subject').value = result.key;
    } else {
        // If the value is not found in storage, you can provide a default value or handle it as needed
        document.getElementById('subject').value = ''; // Replace 'default_value' with your desired default value
    }
});

chrome.storage.session.get(["streakKey"], (result) => {
    if (result.streakKey) {
        streak = result.streakKey;
    } else {
        // If the value is not found in storage, you can provide a default value or handle it as needed
        streak = 10; // Replace 'default_value' with your desired default value
    }
});


// Function to get the tab title
function getTabTitle() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            const tabTitle = tabs[0].title;

            // Call the generateChatResponse function with the tabTitle
            generateChatResponse(tabTitle);
        } else {
            document.getElementById('tab-title').textContent = 'No active tab found.';
        }
    });
}

// Function to generate ChatGPT response with the tabTitle and subject parameters
async function generateChatResponse(tabTitle, subject) {
    const apiKey = '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';
    const endpoint = 'https://api.openai.com/v1/chat/completions';

    const userInput = document.getElementById('subject').value; // Get the value from the text input

    let prompt = `Respond yes or no in one word, Is the website title '${tabTitle}' relevant or related to the topic of ${userInput}?`;

    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [
                {
                    role: 'system',
                    content: 'You are a helpful assistant.',
                },
                {
                    role: 'user',
                    content: prompt,
                },
            ],
        }),
    });


    const responseData = await response.json();
    const chatResponse = responseData.choices[0].message.content;

    document.getElementById('response').innerHTML = `<p>${chatResponse}</p>`;
    // Save chatResponse to Chrome storage
    // chrome.storage.local.set({ chatResponse: chatResponse }, () => {
    //     console.log("Data saved to chrome.storage.local");
      
    //     // Send a message to the background script to indicate that data is saved
    //     chrome.runtime.sendMessage({ dataSaved: true });
    //   });








// Check the condition and update progressBar width every second
setInterval(() => {
    const progressBar = document.getElementById("progress");
    const currentWidth = parseInt(progressBar.style.width) || 0;
    if (
      document.getElementById('response').innerHTML === '<p>Yes</p>' ||
      document.getElementById('response').innerHTML === '<p>Yes.</p>' ||
      document.getElementById('response').innerHTML === '<p>yes</p>' ||
      document.getElementById('response').innerHTML === '<p>yes.</p>'
    ) {
        document.getElementById("madgif").classList.add('hide');
        document.getElementById('happygif').classList.remove('hide');

      // Increment the width by 40 pixels, but ensure it doesn't exceed the maximum value (100)
      const newWidth = currentWidth + 23;
      progressBar.style.width = newWidth <= 100 ? newWidth + "px" : "300px";
      console.log(progressBar.style.width);
      streak = Math.floor(1.3* (streak + 1));
      console.log(streak);
      chrome.storage.session.set({ streakKey: streak}).then(() => {
        console.log("Value is set for current streak");
      });
      document.getElementById("streakDiv").innerHTML = `<p id="streakParagraph" style = "color: white;">${streak}x COMBO</p>`

      if (streak >= 1000000) {
        streak = 1000000;
        document.getElementById("streakParagraph").style.color = 'gold';
        document.getElementById("streakParagraph").style.fontWeight = 'bold';
      }
    } else {
        document.getElementById("happygif").classList.add('hide');
        document.getElementById('madgif').classList.remove('hide');
      // Decrement the width by 40 pixels, but ensure it doesn't go below the minimum value (0)
      const newWidth = currentWidth - 30;
      progressBar.style.width = newWidth >= 0 ? newWidth + "px" : "0px";
      console.log(progressBar.style.width);
      streak = Math.floor(streak / 1.5)
      chrome.storage.session.set({ streakKey: streak}).then(() => {
        console.log("Value is set for current streak");
      });
      document.getElementById("streakDiv").innerHTML = `<p id="streakParagraph" style = "color: white;">${streak}x COMBO</p>`
    }
  }, 2000);
  
    
}

// function streak(isYesReponse){
//     let currentStreak = 0;
//     if isYesResponse
    
// }

// Add an event listener to the button with the ID "lock-in"
document.getElementById('lock-in').addEventListener('click', () => {
    // Call the generateChatResponse function when the button is clicked
    getTabTitle();
    chrome.storage.session.set({ key: document.getElementById('subject').value}).then(() => {
        console.log("Value is set");

      });
    chrome.storage.session.get(["key"]).then((result) => {
        console.log("Value currently is " + result.key);
      });
});


  // Function to change the width
//   function changeWidth() {
 
//   }
document.addEventListener('DOMContentLoaded',getTabTitle())


