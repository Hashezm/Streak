// // Create a new div element
// const newDiv = document.createElement('div');
// newDiv.textContent = 'This is a custom div at the top of the page';
// newDiv.style.position = 'fixed';

// newDiv.style.width = '100%';
// newDiv.style.backgroundColor = 'lightblue';
// newDiv.style.padding = '10px';
// newDiv.style.zIndex = '9999';


// // Append the div to the body of the page
// document.body.insertBefore(newDiv, document.body.firstChild);



  
  