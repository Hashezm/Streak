const express = require('express');
const { CohereClient } = require('cohere-ai');
require('dotenv').config();

const app = express();
app.use(express.json());
const port = 3000;

const cohere = new CohereClient({
  token: process.env.COHERE_API_KEY
});

app.post('/chat', async (req, res) => {
  try {
    const { message } = req.body;
    const response = await cohere.chat({
      message: message
    });
    res.json(response);
  } catch (error) {
    console.error('Failed to call Cohere API:', error);
    res.status(500).send('Error processing your request');
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
